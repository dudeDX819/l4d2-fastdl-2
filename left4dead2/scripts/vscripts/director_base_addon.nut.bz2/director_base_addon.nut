nanas_kamikaze <- 
{
    settings =
    {
        kamikaze_chance = 10,
        explosion_damage = 25,
        explosion_radius = 150,
        pipebomb_drop_chance = 5
    }

    //------------------------------------------------------------
    // SETTINGS
    //------------------------------------------------------------
    function LoadSettings()
    {
        local path = "kamikaze/settings.cfg";
        local file = FileToString(path);

        if (file != null)
        {
            foreach (line in split(file, "\n"))
            {
                line = strip(line);
                if (line == "" || line.find("//") == 0) continue;

                local p = split(line, "=");
                if (p.len() != 2) continue;

                local k = strip(p[0]);
                local v = strip(p[1]);

                if (k in settings)
                    settings[k] = (v.find(".") != null) ? v.tofloat() : v.tointeger();
            }
        }
        else SaveSettings();
    }

    function SaveSettings()
    {
        local out = "";
        foreach (k,v in settings)
            out += k + " = " + v + "\n";
        StringToFile("kamikaze/settings.cfg", out);
    }

    //------------------------------------------------------------
    function OnGameEvent_round_start(params)
    {
        LoadSettings();

        if (!IsModelPrecached("models/infected/kamikaze.mdl"))
            PrecacheModel("models/infected/kamikaze.mdl");

        SpawnEntityFromTable("logic_timer",
        {
            RefireTime = 0.5,
            OnTimer = "!self,runscriptcode,DirectorScript.nanas_kamikaze.Think()"
        });
    }

    //------------------------------------------------------------
    // REGULAR COMMON FILTER
    //------------------------------------------------------------
    function IsRegularCommon(ent)
    {
        local m = ent.GetModelName();
        if (!m) return false;

        m = m.tolower();
        if (m.find("riot") || m.find("hazmat") || m.find("ceda") ||
            m.find("mud") || m.find("clown") || m.find("fallen") ||
            m.find("roadcrew") || m.find("jimmy"))
            return false;

        return true;
    }

    //------------------------------------------------------------
    // THINK LOOP
    //------------------------------------------------------------
    function Think()
    {
        local ent = null;

        while (ent = Entities.FindByClassname(ent, "infected"))
        {
            if (!ent || !ent.IsValid())
                continue;

            ent.ValidateScriptScope();
            local s = ent.GetScriptScope();

            if ("IsKamikaze" in s)
            {
                if (!("WasAlive" in s))
                    s.WasAlive <- true;

                if (s.WasAlive && ent.GetHealth() <= 0)
                {
                    s.WasAlive = false;
                    DropPipeBomb(ent);
                }
                continue;
            }

            if (ent.GetHealth() <= 0)
                continue;

            if (!IsRegularCommon(ent))
                continue;

            if ("Checked" in s)
                continue;

            s.Checked <- true;

            if (RandomInt(1, settings.kamikaze_chance) == 1)
            {
                ent.ValidateScriptScope();
                s.WasAlive <- true; // set flag immediately for pipebombs

                // schedule conversion with delay
                EntFire(
                    "worldspawn",
                    "RunScriptCode",
                    "DirectorScript.nanas_kamikaze.ConvertDelayed(" + ent.GetEntityIndex() + ")",
                    0.3,
                    null
                );
            }
        }
    }

    //------------------------------------------------------------
    // DELAYED CONVERSION WITH MODEL CHECK
    //------------------------------------------------------------
    function ConvertDelayed(idx)
    {
        local ent = EntIndexToHScript(idx);
        if (!ent || ent.GetHealth() <= 0) return;

        local mdl = ent.GetModelName().tolower();
        if (mdl.find("corpseeater") != null || mdl.find("prisoner") != null || mdl.find("blood_man") != null)
            return;

        ent.ValidateScriptScope();
        local s = ent.GetScriptScope();

        if ("IsKamikaze" in s) return;

        s.IsKamikaze <- true;
        s.WasAlive <- true;

        ent.SetModel("models/infected/kamikaze.mdl");
        NetProps.SetPropInt(ent, "m_iHealth", 50);
        NetProps.SetPropInt(ent, "m_iMaxHealth", 50);
    }

    //------------------------------------------------------------
    // EXPLOSION (MARK CHAIN KILLS)
    //------------------------------------------------------------
    function OnGameEvent_player_hurt(params)
    {
        local atk = ("attackerentid" in params) ? EntIndexToHScript(params.attackerentid) : null;
        if (!atk || atk.GetClassname() != "infected") return;

        atk.ValidateScriptScope();
        if (!("IsKamikaze" in atk.GetScriptScope())) return;

        // mark nearby kamikaze as killed by kamikaze
        local ent = null;
        while (ent = Entities.FindByClassnameWithin(ent, "infected", atk.GetOrigin(), settings.explosion_radius))
        {
            if (!ent || !ent.IsValid()) continue;
            if (ent == atk) continue;

            ent.ValidateScriptScope();
            local s = ent.GetScriptScope();

            if ("IsKamikaze" in s)
                s.KilledByKamikaze <- true;
        }

        // spawn explosion
        local exp = SpawnEntityFromTable("env_explosion",
        {
            iMagnitude = settings.explosion_damage,
            iRadiusOverride = settings.explosion_radius,
            spawnflags = 2,
            origin = atk.GetOrigin() + Vector(0,0,40)
        });

        DoEntFire("!self", "Explode", "", 0, atk, exp);

        // play explosion sound
        EmitAmbientSoundOn("weapons/hegrenade/explode3.wav", 1.0, 100, 100, atk);

        atk.Kill();
    }

    //------------------------------------------------------------
    // PIPE BOMB DROP (NO CHAIN KILLS)
    //------------------------------------------------------------
    function DropPipeBomb(ent)
    {
        ent.ValidateScriptScope();
        local s = ent.GetScriptScope();

        // killed by another kamikaze → no drop
        if ("KilledByKamikaze" in s && s.KilledByKamikaze)
            return;

        if (settings.pipebomb_drop_chance <= 0)
            return;

        if (RandomInt(1, settings.pipebomb_drop_chance) != 1)
            return;

        local pos = ent.GetOrigin();
        SpawnEntityFromTable("weapon_pipe_bomb",
        {
            origin = pos + Vector(0,0,60)
        });
    }
}

nanas_sewer_worker <- 
{
    settings =
    {
        sewer_chance = 12,        // 1 in X commons become sewer workers
        bile_chance  = 4          // 1 in X hits apply bile
    }

    //------------------------------------------------------------
    // SETTINGS
    //------------------------------------------------------------
    function LoadSettings()
    {
        local file = FileToString("sewer_worker/settings.cfg");
        if (!file)
        {
            SaveSettings();
            return;
        }

        foreach (line in split(file, "\n"))
        {
            line = strip(line);
            if (line == "" || line.find("//") == 0) continue;

            local p = split(line, "=");
            if (p.len() != 2) continue;

            local k = strip(p[0]);
            local v = strip(p[1]);

            if (k in settings)
                settings[k] = v.tointeger();
        }
    }

    function SaveSettings()
    {
        local out = "";
        foreach (k,v in settings)
            out += k + " = " + v + "\n";

        StringToFile("sewer_worker/settings.cfg", out);
    }

    //------------------------------------------------------------
    function OnGameEvent_round_start(params)
    {
        LoadSettings();

        if (!IsModelPrecached("models/infected/sewer_worker.mdl"))
            PrecacheModel("models/infected/sewer_worker.mdl");

        SpawnEntityFromTable("logic_timer",
        {
            RefireTime = 0.5,
            OnTimer = "!self,runscriptcode,DirectorScript.nanas_sewer_worker.Think()"
        });
    }

    //------------------------------------------------------------
    // THINK LOOP
    //------------------------------------------------------------
    function Think()
    {
        local ent = null;
        while (ent = Entities.FindByClassname(ent, "infected"))
        {
            if (!ent || ent.GetHealth() <= 0) continue;

            ent.ValidateScriptScope();
            local s = ent.GetScriptScope();

            if ("Checked" in s) continue;
            s.Checked <- true;

            if (RandomInt(1, settings.sewer_chance) == 1)
            {
                EntFire(
                    "worldspawn",
                    "RunScriptCode",
                    "DirectorScript.nanas_sewer_worker.ConvertDelayed(" + ent.GetEntityIndex() + ")",
                    0.7,
                    null
                );
            }
        }
    }

    //------------------------------------------------------------
    // DELAYED CONVERSION (ALL CHECKS HERE)
    //------------------------------------------------------------
    function ConvertDelayed(idx)
    {
        local ent = EntIndexToHScript(idx);
        if (!ent || ent.GetHealth() <= 0) return;

        local mdl = ent.GetModelName();
        if (!mdl) return;

        mdl = mdl.tolower();

        // compatibility with other mods
        if (mdl.find("corpseeater") != null) return;
        if (mdl.find("prisoner") != null) return;
        if (mdl.find("rat") != null) return;
        if (mdl.find("blood") != null) return;
        if (mdl.find("kamikaze") != null) return;
        if (mdl.find("fireman") != null) return;
        if (mdl.find("park_ranger") != null) return;
		if (mdl.find("common_male_police_l4d2") != null) return;
        if (mdl.find("paramedic") != null) return;
        if (mdl.find("riot") != null) return;
        if (mdl.find("hazmat") != null) return;
        if (mdl.find("ceda") != null) return;
        if (mdl.find("clown") != null) return;
        if (mdl.find("mud") != null) return;
        if (mdl.find("fallen") != null) return;
        if (mdl.find("roadcrew") != null) return;
        if (mdl.find("jimmy") != null) return;


        ent.ValidateScriptScope();
        local s = ent.GetScriptScope();

        if ("IsSewerWorker" in s) return;

        s.IsSewerWorker <- true;

        ent.SetModel("models/infected/sewer_worker.mdl");
        NetProps.SetPropInt(ent, "m_iHealth", 60);
        NetProps.SetPropInt(ent, "m_iMaxHealth", 60);
    }

    //------------------------------------------------------------
    // BILE ON HIT
    //------------------------------------------------------------
    function OnGameEvent_player_hurt(params)
    {
        local victim = ("userid" in params) ? GetPlayerFromUserID(params.userid) : null;
        local atk    = ("attackerentid" in params) ? EntIndexToHScript(params.attackerentid) : null;

        if (!victim || !atk) return;
        if (!victim.IsSurvivor()) return;
        if (atk.GetClassname() != "infected") return;

        atk.ValidateScriptScope();
        local s = atk.GetScriptScope();

        if (!("IsSewerWorker" in s)) return;

        if (RandomInt(1, settings.bile_chance) != 1)
            return;

        victim.HitWithVomit();
    }
}

nanas_prisoner <-
{
	settings =
	{
		prisoner_chance = 10,
		disarm_chance   = 33
	}

	//------------------------------------------------------------
	// SETTINGS
	//------------------------------------------------------------
	function LoadSettings()
	{
		local path = "prisoner/settings.cfg";
		local file = FileToString(path);

		if (file != null)
		{
			local lines = split(file, "\n");
			foreach (line in lines)
			{
				line = strip(line);
				if (line == "" || line.find("//") == 0) continue;

				local parts = split(line, "=");
				if (parts.len() == 2)
				{
					local key = strip(parts[0]);
					local val = strip(parts[1]);

					if (key in settings)
					{
						if (val.find(".") != null)
							settings[key] = val.tofloat();
						else
							settings[key] = val.tointeger();
					}
				}
			}
			printl("[prisoner] Settings loaded");
		}
		else SaveSettings();
	}

	function SaveSettings()
	{
		local path = "prisoner/settings.cfg";
		local content = "";
		foreach (key, val in settings)
			content += key + " = " + val.tostring() + "\n";
		StringToFile(path, content);
	}

	//------------------------------------------------------------
	// ROUND START
	//------------------------------------------------------------
	function OnGameEvent_round_start(params)
	{
		LoadSettings();

		if (!IsModelPrecached("models/infected/prisoner.mdl"))
			PrecacheModel("models/infected/prisoner.mdl");

		SpawnEntityFromTable("logic_timer",
		{
			RefireTime = 0.5,
			OnTimer = "!self,runscriptcode,DirectorScript.nanas_prisoner.ScanCommons()"
		});
	}

	//------------------------------------------------------------
	// REGULAR COMMON CHECK (UNCOMMON FILTER ONLY)
	//------------------------------------------------------------
	function IsRegularCommon(common)
	{
		local mdl = common.GetModelName();
		if (!mdl) return false;

		mdl = mdl.tolower();

		if (mdl.find("riot")     != null) return false;
		if (mdl.find("hazmat")   != null) return false;
		if (mdl.find("mud")      != null) return false;
		if (mdl.find("clown")    != null) return false;
		if (mdl.find("ceda")     != null) return false;
		if (mdl.find("roadcrew") != null) return false;
		if (mdl.find("fallen")   != null) return false;
		if (mdl.find("jimmy")    != null) return false;

		return true;
	}

	//------------------------------------------------------------
	// MAIN SCAN
	//------------------------------------------------------------
	function ScanCommons()
	{
		local common = null;

		while (common = Entities.FindByClassname(common, "infected"))
		{
			if (!common || common.GetHealth() <= 0)
				continue;

			if (!IsRegularCommon(common))
				continue;

			if (!common.ValidateScriptScope())
				continue;

			local scope = common.GetScriptScope();

			if ("PrisonerChecked" in scope)
				continue;

			scope.PrisonerChecked <- 1;

			if (RandomInt(1, settings.prisoner_chance) == 1)
			{
				EntFire(
					"worldspawn",
					"RunScriptCode",
					"DirectorScript.nanas_prisoner.DelayedConvertPrisoner(" + common.GetEntityIndex() + ")",
					0.2,
					null
				);
			}
		}
	}

	//------------------------------------------------------------
	// DELAYED CONVERSION (CORPSE EATER SAFE)
	//------------------------------------------------------------
	function DelayedConvertPrisoner(ent_idx)
	{
		local common = EntIndexToHScript(ent_idx);
		if (!common || common.GetHealth() <= 0)
			return;

		local mdl = common.GetModelName();
        if (mdl.find("corpseeater") != null || mdl.find("rat") != null || mdl.find("blood") != null)
			return;

		common.ValidateScriptScope();
		local scope = common.GetScriptScope();

		if ("IsPrisoner" in scope)
			return;

		scope.IsPrisoner <- 1;

		common.SetModel("models/infected/prisoner.mdl");

		local hp = 100;
		NetProps.SetPropInt(common, "m_iMaxHealth", hp);
		NetProps.SetPropInt(common, "m_iHealth", hp);

		NetProps.SetPropInt(common,
			"m_fFlags",
			NetProps.GetPropInt(common, "m_fFlags") & ~256);

		NetProps.SetPropIntArray(common,
			"m_NetGestureSequence",
			common.LookupSequence("ACT_RUN"), 6);
		NetProps.SetPropIntArray(common,
			"m_NetGestureActivity",
			common.LookupActivity("ACT_RUN"), 6);
		NetProps.SetPropFloatArray(common,
			"m_NetGestureStartTime",
			Time(), 6);
	}

	//------------------------------------------------------------
	// DISARM MECHANIC
	//------------------------------------------------------------
	function OnGameEvent_player_hurt(event)
	{
		local victim = null;
		if ("userid" in event)
			victim = GetPlayerFromUserID(event.userid);

		if (!victim || !victim.IsSurvivor())
			return;

		local attacker = null;
		if ("attackerentid" in event)
			attacker = EntIndexToHScript(event.attackerentid);

		if (!attacker || attacker.GetClassname() != "infected")
			return;

		try { attacker.ValidateScriptScope(); } catch (e) {}
		local scope = attacker.GetScriptScope();

		if (!scope || !("IsPrisoner" in scope))
			return;

		if (RandomInt(1, 100) > settings.disarm_chance)
			return;

		local inv = {};
		GetInvTable(victim, inv);

		if ("slot0" in inv && inv.slot0)
		{
			victim.DropItem(inv.slot0.GetClassname());
		}
	}
}

nanas_corpse_eater <-
{
	settings =
	{
		corpse_eater_chance = 10, 
		bleed_amount = 10
	}

	//------------------------------------------------------------
	// SETTINGS
	//------------------------------------------------------------
	function LoadSettings()
	{
		local path = "corpse_eater/settings.cfg";
		local file = FileToString(path);

		if (file != null)
		{
			local lines = split(file, "\n");
			foreach (line in lines)
			{
				line = strip(line);
				if (line == "" || line.find("//") == 0) continue;

				local parts = split(line, "=");
				if (parts.len() == 2)
				{
					local key = strip(parts[0]);
					local val = strip(parts[1]);

					if (key in settings)
					{
						if (val.find(".") != null)
							settings[key] = val.tofloat();
						else
							settings[key] = val.tointeger();
					}
				}
			}
			printl("[corpse_eater] Settings loaded");
		}
		else
		{
			SaveSettings();
		}
	}

	function SaveSettings()
	{
		local path = "corpse_eater/settings.cfg";
		local content = "";
		foreach (key, val in settings)
			content += key + " = " + val.tostring() + "\n";
		StringToFile(path, content);
	}

	//------------------------------------------------------------
	// ROUND START
	//------------------------------------------------------------
	function OnGameEvent_round_start(params)
	{
		LoadSettings();

		if (!IsModelPrecached("models/infected/corpseeater.mdl"))
			PrecacheModel("models/infected/corpseeater.mdl");

		// thinker
		SpawnEntityFromTable("logic_timer",
		{
			RefireTime = 0.5,
			OnTimer = "!self,runscriptcode,DirectorScript.nanas_corpse_eater.ScanCommons()"
		});
	}

	//------------------------------------------------------------
	// REGULAR COMMON CHECK (EXCLUDES UNCOMMONS)
	//------------------------------------------------------------
	function IsRegularCommon(common)
	{
		local mdl = common.GetModelName();
		if (!mdl) return false;

		mdl = mdl.tolower();

		if (mdl.find("riot")   != null) return false;
		if (mdl.find("hazmat") != null) return false;
		if (mdl.find("mud")    != null) return false;
		if (mdl.find("clown")  != null) return false;
		if (mdl.find("ceda")   != null) return false;
		if (mdl.find("roadcrew") != null) return false;
	    if (mdl.find("fallen")   != null) return false;
		if (mdl.find("jimmy")   != null) return false;

		return true;
	}

	//------------------------------------------------------------
	// MAIN SCAN (CALLED BY logic_timer)
	//------------------------------------------------------------
	function ScanCommons()
	{
		local common = null;

		while (common = Entities.FindByClassname(common, "infected"))
		{
			if (!common || common.GetHealth() <= 0)
				continue;

			if (!IsRegularCommon(common))
				continue;

			if (!common.ValidateScriptScope())
				continue;

			local scope = common.GetScriptScope();

			// one roll per common
			if ("CorpseEaterChecked" in scope)
				continue;

			scope.CorpseEaterChecked <- 1;

			if (RandomInt(1, settings.corpse_eater_chance) == 1)
			{
				DelayedConvertCorpse_Eater(common.GetEntityIndex());
			}
		}
	}

	//------------------------------------------------------------
	// CONVERSION
	//------------------------------------------------------------
	function DelayedConvertCorpse_Eater(ent_idx)
	{
		local common = EntIndexToHScript(ent_idx);
		if (!common || common.GetClassname() != "infected" || common.GetHealth() <= 0)
			return;

		common.ValidateScriptScope();
		local scope = common.GetScriptScope();

		if ("IsCorpse_Eater" in scope)
			return;

		scope.IsCorpse_Eater <- 1;

		// model
		common.SetModel("models/infected/corpseeater.mdl");

		// health (netprops so it sticks)
		local hp = 100;
		NetProps.SetPropInt(common, "m_iMaxHealth", hp);
		NetProps.SetPropInt(common, "m_iHealth", hp);

		NetProps.SetPropInt(
			common,
			"m_fFlags",
			NetProps.GetPropInt(common, "m_fFlags") & ~256
		);

		NetProps.SetPropIntArray(common,
			"m_NetGestureSequence",
			common.LookupSequence("ACT_RUN"), 6);
		NetProps.SetPropIntArray(common,
			"m_NetGestureActivity",
			common.LookupActivity("ACT_RUN"), 6);
		NetProps.SetPropFloatArray(common,
			"m_NetGestureStartTime",
			Time(), 6);
	}

	//------------------------------------------------------------
	// BLEED MECHANIC
	//------------------------------------------------------------
	function OnGameEvent_player_hurt(params)
	{
		local victim = null;
		if ("userid" in params)
			victim = GetPlayerFromUserID(params.userid);

		if (!victim || !victim.IsSurvivor())
			return;

		local attacker = null;
		if ("attackerentid" in params)
			attacker = EntIndexToHScript(params.attackerentid);

		if (!attacker || attacker.GetClassname() != "infected")
			return;

		try { attacker.ValidateScriptScope(); } catch (e) {}
		local scope = attacker.GetScriptScope();

		if (!scope || !("IsCorpse_Eater" in scope))
			return;

		local bleed = settings.bleed_amount;
		local curHealth = victim.GetHealth();

		if (curHealth > bleed)
		{
			victim.SetHealth(curHealth - bleed);

			local curBuf = 0;
			try { curBuf = victim.GetHealthBuffer(); }
			catch (e) { curBuf = NetProps.GetPropFloat(victim, "m_healthBuffer"); }

			try { victim.SetHealthBuffer(curBuf + bleed); }
			catch (e) { NetProps.SetPropFloat(victim, "m_healthBuffer", curBuf + bleed); }
		}
		else
		{
			victim.TakeDamage(curHealth, 0, attacker);
		}
	}
}

//------------------------------------------------------------
// REGISTER
//------------------------------------------------------------
IncludeScript( "Spear" );

DirectorScript.nanas_corpse_eater <- nanas_corpse_eater;
__CollectGameEventCallbacks(nanas_corpse_eater);
IncludeScript("corpse_eater/common_anim_fix4.nut", getroottable());
try { nanas_corpse_eater.LoadSettings(); } catch (e) {}

DirectorScript.nanas_prisoner <- nanas_prisoner;
__CollectGameEventCallbacks(nanas_prisoner);
IncludeScript("prisoner/common_anim_fix3.nut", getroottable());
try { nanas_prisoner.LoadSettings(); } catch (e) {}

DirectorScript.nanas_sewer_worker <- nanas_sewer_worker;
__CollectGameEventCallbacks(nanas_sewer_worker);
IncludeScript("sewer_worker/common_anim_fix5.nut", getroottable());
try { nanas_sewer_worker.LoadSettings(); } catch (e) {}

DirectorScript.nanas_kamikaze <- nanas_kamikaze;
__CollectGameEventCallbacks(nanas_kamikaze);
IncludeScript("kamikaze/common_anim_fix2.nut", getroottable());
try { nanas_kamikaze.LoadSettings(); } catch (e) {}